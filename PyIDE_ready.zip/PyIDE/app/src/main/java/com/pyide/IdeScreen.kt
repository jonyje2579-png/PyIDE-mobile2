package com.pyide

import androidx.compose.runtime.Composable

/** Оставлено для совместимости со старым кодом. Весь интерфейс теперь в MainScreen.kt. */
@Composable
fun IdeScreen(ide: Ide) = MainScreen(ide)
